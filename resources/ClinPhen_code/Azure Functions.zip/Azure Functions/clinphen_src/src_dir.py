#!/usr/bin/env python

import sys
import os
import argparse
myDir = "/".join(os.path.realpath(__file__).split("/")[:-1])

def get_src_dir(): return myDir
