pyinstaller ClinPhenApp -p clinphen_src/ --add-data 'clinphen_src/data:clinphen_src/data/' --add-data 'clinphen_src/misc:clinphen_src/misc/' -F

